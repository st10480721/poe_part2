package loginsystem_;

public class RunAllTests {
    
    private static int passed = 0;
    private static int failed = 0;
    private static LoginSystem_ loginSystem;
    
    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println("     RUNNING LOGIN SYSTEM TESTS");
        System.out.println("==========================================\n");
        
        // Initialize fresh login system for each test
        loginSystem = new LoginSystem_();
        
        // Run all tests
        testCheckUserName_Valid();
        testCheckUserName_InvalidNoUnderscore();
        testCheckUserName_InvalidTooLong();
        testCheckUserName_InvalidNull();
        
        testCheckPasswordComplexity_Valid();
        testCheckPasswordComplexity_NoUppercase();
        testCheckPasswordComplexity_NoNumber();
        testCheckPasswordComplexity_NoSpecial();
        testCheckPasswordComplexity_TooShort();
        
        testCheckCellPhoneNumber_Valid();
        testCheckCellPhoneNumber_InvalidNoPlus27();
        testCheckCellPhoneNumber_InvalidWrongLength();
        
        testRegisterUser_Success();
        testRegisterUser_InvalidUsername();
        testRegisterUser_InvalidPassword();
        testRegisterUser_InvalidCellNumber();
        
        testLoginUser_Success();
        testLoginUser_WrongPassword();
        testLoginUser_WrongUsername();
        
        testReturnLoginStatus_Success();
        testReturnLoginStatus_Failed();
        
        testCompleteRegistrationAndLoginFlow();
        
        // Print summary
        System.out.println("\n==========================================");
        System.out.println("TEST SUMMARY");
        System.out.println("==========================================");
        System.out.println("Total Tests: " + (passed + failed));
        System.out.println("Passed: " + passed);
        System.out.println("Failed: " + failed);
        System.out.println("==========================================");
        
        if (failed == 0) {
            System.out.println("\n✓✓✓ ALL TESTS PASSED! ✓✓✓");
        } else {
            System.out.println("\n✗✗✗ " + failed + " TEST(S) FAILED! ✗✗✗");
        }
    }
    
    private static void test(String testName, boolean condition) {
        if (condition) {
            System.out.println("  ✓ PASS: " + testName);
            passed++;
        } else {
            System.out.println("  ✗ FAIL: " + testName);
            failed++;
        }
    }
    
    // ==================== USERNAME TESTS ====================
    
    private static void testCheckUserName_Valid() {
        System.out.println("\n--- Testing checkUserName() - Valid Usernames ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Username 'kyl_1' should be valid", loginSystem.checkUserName("kyl_1"));
        test("Username 'a_b_c' should be valid", loginSystem.checkUserName("a_b_c"));
        test("Username 'user_' should be valid", loginSystem.checkUserName("user_"));
    }
    
    private static void testCheckUserName_InvalidNoUnderscore() {
        System.out.println("\n--- Testing checkUserName() - No Underscore ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Username 'kyle1' should fail (no underscore)", !loginSystem.checkUserName("kyle1"));
        test("Username 'kyle' should fail (no underscore)", !loginSystem.checkUserName("kyle"));
    }
    
    private static void testCheckUserName_InvalidTooLong() {
        System.out.println("\n--- Testing checkUserName() - Too Long ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Username 'kyle_1' should fail (longer than 5 chars)", !loginSystem.checkUserName("kyle_1"));
        test("Username 'user_123' should fail (longer than 5 chars)", !loginSystem.checkUserName("user_123"));
    }
    
    private static void testCheckUserName_InvalidNull() {
        System.out.println("\n--- Testing checkUserName() - Null ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Username 'null' should fail", !loginSystem.checkUserName(null));
    }
    
    // ==================== PASSWORD TESTS ====================
    
    private static void testCheckPasswordComplexity_Valid() {
        System.out.println("\n--- Testing checkPasswordComplexity() - Valid Passwords ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Password 'Password1!' should be valid", loginSystem.checkPasswordComplexity("Password1!"));
        test("Password 'MyPass@123' should be valid", loginSystem.checkPasswordComplexity("MyPass@123"));
        test("Password 'Ch&sec@ke99!' should be valid", loginSystem.checkPasswordComplexity("Ch&sec@ke99!"));
    }
    
    private static void testCheckPasswordComplexity_NoUppercase() {
        System.out.println("\n--- Testing checkPasswordComplexity() - No Uppercase ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Password 'password1!' should fail (no uppercase)", !loginSystem.checkPasswordComplexity("password1!"));
        test("Password 'mypass@123' should fail (no uppercase)", !loginSystem.checkPasswordComplexity("mypass@123"));
    }
    
    private static void testCheckPasswordComplexity_NoNumber() {
        System.out.println("\n--- Testing checkPasswordComplexity() - No Number ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Password 'Password!!' should fail (no number)", !loginSystem.checkPasswordComplexity("Password!!"));
        test("Password 'MyPass@@' should fail (no number)", !loginSystem.checkPasswordComplexity("MyPass@@"));
    }
    
    private static void testCheckPasswordComplexity_NoSpecial() {
        System.out.println("\n--- Testing checkPasswordComplexity() - No Special Character ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Password 'Password123' should fail (no special)", !loginSystem.checkPasswordComplexity("Password123"));
        test("Password 'MyPass123' should fail (no special)", !loginSystem.checkPasswordComplexity("MyPass123"));
    }
    
    private static void testCheckPasswordComplexity_TooShort() {
        System.out.println("\n--- Testing checkPasswordComplexity() - Too Short ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Password 'Ab1!' should fail (less than 8 chars)", !loginSystem.checkPasswordComplexity("Ab1!"));
        test("Password 'Pass1!' should fail (less than 8 chars)", !loginSystem.checkPasswordComplexity("Pass1!"));
    }
    
    // ==================== PHONE TESTS ====================
    
    private static void testCheckCellPhoneNumber_Valid() {
        System.out.println("\n--- Testing checkCellPhoneNumber() - Valid Numbers ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Phone '+27781234567' should be valid", loginSystem.checkCellPhoneNumber("+27781234567"));
        test("Phone '+27831234567' should be valid", loginSystem.checkCellPhoneNumber("+27831234567"));
        test("Phone '+27829876543' should be valid", loginSystem.checkCellPhoneNumber("+27829876543"));
    }
    
    private static void testCheckCellPhoneNumber_InvalidNoPlus27() {
        System.out.println("\n--- Testing checkCellPhoneNumber() - No +27 Prefix ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Phone '0812345678' should fail (no +27)", !loginSystem.checkCellPhoneNumber("0812345678"));
        test("Phone '0831234567' should fail (no +27)", !loginSystem.checkCellPhoneNumber("0831234567"));
        test("Phone '2781234567' should fail (no +)", !loginSystem.checkCellPhoneNumber("2781234567"));
    }
    
    private static void testCheckCellPhoneNumber_InvalidWrongLength() {
        System.out.println("\n--- Testing checkCellPhoneNumber() - Wrong Length ---");
        loginSystem = new LoginSystem_(); // Reset
        test("Phone '+2778123456' should fail (too short)", !loginSystem.checkCellPhoneNumber("+2778123456"));
        test("Phone '+277812345678' should fail (too long)", !loginSystem.checkCellPhoneNumber("+277812345678"));
    }
    
    // ==================== REGISTRATION TESTS ====================
    
    private static void testRegisterUser_Success() {
        System.out.println("\n--- Testing registerUser() - Success ---");
        loginSystem = new LoginSystem_(); // Reset
        String result = loginSystem.registerUser("joh_1", "Test@1234", "+27831234567", "John", "Doe");
        test("Registration should succeed with correct inputs", result.equals("User successfully registered!"));
    }
    
    private static void testRegisterUser_InvalidUsername() {
        System.out.println("\n--- Testing registerUser() - Invalid Username ---");
        loginSystem = new LoginSystem_(); // Reset
        String result = loginSystem.registerUser("kyle_1", "Password1!", "+27781234567", "Kyle", "Smith");
        test("Should reject invalid username", result.contains("Username is not correctly formatted"));
    }
    
    private static void testRegisterUser_InvalidPassword() {
        System.out.println("\n--- Testing registerUser() - Invalid Password ---");
        loginSystem = new LoginSystem_(); // Reset
        String result = loginSystem.registerUser("kyl_1", "weak", "+27781234567", "Kyle", "Smith");
        test("Should reject weak password", result.contains("Password is not correctly formatted"));
    }
    
    private static void testRegisterUser_InvalidCellNumber() {
        System.out.println("\n--- Testing registerUser() - Invalid Cell Number ---");
        loginSystem = new LoginSystem_(); // Reset
        String result = loginSystem.registerUser("kyl_1", "Password1!", "0812345678", "Kyle", "Smith");
        test("Should reject invalid phone number", result.contains("Cell phone number incorrectly formatted"));
    }
    
    // ==================== LOGIN TESTS ====================
    
    private static void testLoginUser_Success() {
        System.out.println("\n--- Testing loginUser() - Success ---");
        loginSystem = new LoginSystem_(); // Reset
        loginSystem.registerUser("joh_1", "Test@1234", "+27831234567", "John", "Doe");
        test("Login should succeed with correct credentials", loginSystem.loginUser("joh_1", "Test@1234"));
    }
    
    private static void testLoginUser_WrongPassword() {
        System.out.println("\n--- Testing loginUser() - Wrong Password ---");
        loginSystem = new LoginSystem_(); // Reset
        loginSystem.registerUser("joh_1", "Test@1234", "+27831234567", "John", "Doe");
        test("Login should fail with wrong password", !loginSystem.loginUser("joh_1", "WrongPass123!"));
    }
    
    private static void testLoginUser_WrongUsername() {
        System.out.println("\n--- Testing loginUser() - Wrong Username ---");
        loginSystem = new LoginSystem_(); // Reset
        loginSystem.registerUser("joh_1", "Test@1234", "+27831234567", "John", "Doe");
        test("Login should fail with wrong username", !loginSystem.loginUser("wrong", "Test@1234"));
    }
    
    // ==================== LOGIN STATUS TESTS ====================
    
    private static void testReturnLoginStatus_Success() {
        System.out.println("\n--- Testing returnLoginStatus() - Success ---");
        loginSystem = new LoginSystem_(); // Reset
        loginSystem.registerUser("joh_1", "Test@1234", "+27831234567", "John", "Doe");
        String result = loginSystem.returnLoginStatus("joh_1", "Test@1234");
        test("Should return welcome message", result.equals("Welcome John, Doe it is great to see you again."));
    }
    
    private static void testReturnLoginStatus_Failed() {
        System.out.println("\n--- Testing returnLoginStatus() - Failed ---");
        loginSystem = new LoginSystem_(); // Reset
        loginSystem.registerUser("joh_1", "Test@1234", "+27831234567", "John", "Doe");
        String result = loginSystem.returnLoginStatus("wrong", "Test@1234");
        test("Should return error message", result.equals("Username or password incorrect, please try again."));
    }
    
    // ==================== COMPLETE FLOW TEST ====================
    
    private static void testCompleteRegistrationAndLoginFlow() {
        System.out.println("\n--- Testing Complete Registration and Login Flow ---");
        loginSystem = new LoginSystem_(); // Reset
        String regResult = loginSystem.registerUser("flow_1", "FlowTest@99", "+27789999999", "Flow", "User");
        test("Registration should work", regResult.equals("User successfully registered!"));
        
        test("Login should work after registration", loginSystem.loginUser("flow_1", "FlowTest@99"));
        
        String welcome = loginSystem.returnLoginStatus("flow_1", "FlowTest@99");
        test("Welcome message should be correct", welcome.equals("Welcome Flow, User it is great to see you again."));
    }
}