/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginsystem_;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author Student
 */
public class LoginSystem_ {
    
    private String storedUsername;
    private String storedPassword;
    private String firstName;
    private String lastName;
    
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        
        boolean hasCapital = false, hasNumber = false, hasSpecial = false;
        String specialChars = "!@#$%^&*()_+{}:<>?~`-=[]\\;',./";
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            else if (Character.isDigit(c)) hasNumber = true;
            else if (specialChars.indexOf(c) != -1) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }
    
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber != null && Pattern.matches("^\\+27[0-9]{9}$", cellNumber);
    }
    
    public String registerUser(String username, String password, String cellNumber, String firstName, String lastName) {
        if (!checkUserName(username)) 
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        if (!checkPasswordComplexity(password)) 
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        if (!checkCellPhoneNumber(cellNumber)) 
            return "Cell phone number incorrectly formatted or does not contain international code.";
        
        this.storedUsername = username;
        this.storedPassword = password;
        this.firstName = firstName;
        this.lastName = lastName;
        return "User successfully registered!";
    }
    
    public boolean loginUser(String username, String password) {
        return storedUsername != null && storedUsername.equals(username) && storedPassword.equals(password);
    }
    
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) 
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        return "Username or password incorrect, please try again.";
    }
    
   
    public static void main(String[] args) {
        LoginSystem_ loginSystem = new LoginSystem_();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=== USER REGISTRATION ===");
        System.out.print("Enter First Name: ");
        String fName = scanner.nextLine();
        
        System.out.print("Enter Last Name: ");
        String lName = scanner.nextLine();
        
        System.out.print("Create Username (must have _ and max 5 chars): ");
        String user = scanner.nextLine();
        
        System.out.print("Create Password (8+ chars, Uppercase, Number, Special): ");
        String pass = scanner.nextLine();
        
        System.out.print("Enter Cell Number (+27...): ");
        String cell = scanner.nextLine();

       
        String regStatus = loginSystem.registerUser(user, pass, cell, fName, lName);
        System.out.println("\n" + regStatus);

     
        if (regStatus.equals("User successfully registered!")) {
            System.out.println("\n=== USER LOGIN ===");
            System.out.print("Enter Username: ");
            String logUser = scanner.nextLine();
            
            System.out.print("Enter Password: ");
            String logPass = scanner.nextLine();
            
          
            System.out.println("\n" + loginSystem.returnLoginStatus(logUser, logPass));
            
            // Create message object and call runQuickChat
            if (loginSystem.loginUser(logUser, logPass)) {
                MessageSystem msgApp = new MessageSystem();
                msgApp.runQuickChat();
            }
        }
        
        scanner.close();
    }
}