/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginsystem_;
import java.util.regex.Pattern;
import java.util.Scanner;
import java.util.*;
import java.io.*;

class Message {
    private String messageId;
    private String messageHash;
    private String recipient;
    private String messageText;
    private int messageNumber;
    private String timestamp;
    
    public Message(String messageId, String messageHash, String recipient, 
                   String messageText, int messageNumber) {
        this.messageId = messageId;
        this.messageHash = messageHash;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.timestamp = new Date().toString();
    }
    
    public String getMessageId() { return messageId; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public int getMessageNumber() { return messageNumber; }
    public String getTimestamp() { return timestamp; }
}

public class MessageSystem {  // CHANGED: from "message" to "MessageSystem"
    
    private String storedUsername;
    private String storedPassword;
    private String firstName;
    private String lastName;
    
    private Scanner scanner;
    private List<Message> messagesSent;
    private List<Message> messagesStored;
    private int messageCounter;
    private int totalMessagesAllowed;
    private boolean loggedIn;
    
    public MessageSystem() {  // CHANGED: constructor name
        scanner = new Scanner(System.in);
        messagesSent = new ArrayList<>();
        messagesStored = new ArrayList<>();
        messageCounter = 0;
        totalMessagesAllowed = 0;
        loggedIn = false;
    }
    
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        
        boolean hasCapital = false, hasNumber = false, hasSpecial = false;
        String specialChars = "!@#$%^&*()_+{}:<>?~`-=[]\\;',./";
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            else if (Character.isDigit(c)) hasNumber = true;
            else if (specialChars.indexOf(c) != -1) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }
    
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber != null && Pattern.matches("^\\+27[0-9]{9}$", cellNumber);
    }
    
    public String registerUser(String username, String password, String cellNumber, String firstName, String lastName) {
        if (!checkUserName(username)) 
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        if (!checkPasswordComplexity(password)) 
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        if (!checkCellPhoneNumber(cellNumber)) 
            return "Cell phone number incorrectly formatted or does not contain international code.";
        
        this.storedUsername = username;
        this.storedPassword = password;
        this.firstName = firstName;
        this.lastName = lastName;
        return "User successfully registered!";
    }
    
    public boolean loginUser(String username, String password) {
        return storedUsername != null && storedUsername.equals(username) && storedPassword.equals(password);
    }
    
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            loggedIn = true;
            return "Welcome " + firstName + " " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
    
    public void displayWelcome() {
        System.out.println("\n==================================================");
        System.out.println("Welcome to QuickChat");
        System.out.println("==================================================");
    }
    
    public boolean getTotalMessages() {
        while (true) {
            try {
                System.out.print("\nHow many messages do you wish to enter? ");
                totalMessagesAllowed = Integer.parseInt(scanner.nextLine());
                if (totalMessagesAllowed > 0) {
                    return true;
                } else {
                    System.out.println("Please enter a positive number.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
    
    public boolean checkMessageID(String messageId) {
        return messageId.length() <= 10;
    }
    
    public String checkRecipientCell(String recipient) {
        recipient = recipient.trim();
        
        if (!recipient.startsWith("+")) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        String numberPart = recipient.substring(1);
        
        if (numberPart.length() < 8 || numberPart.length() > 15) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        if (!numberPart.matches("\\d+")) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        return "Cell phone number successfully captured.";
    }
    
    public String createMessageHash(String messageId, int messageNumber, String messageText) {
        String[] words = messageText.trim().split("\\s+");
        
        String firstWord = "";
        String lastWord = "";
        
        if (words.length == 0) {
            firstWord = "";
            lastWord = "";
        } else if (words.length == 1) {
            firstWord = words[0];
            lastWord = words[0];
        } else {
            firstWord = words[0];
            lastWord = words[words.length - 1];
        }
        
        String firstTwo = messageId.substring(0, Math.min(2, messageId.length()));
        
        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
    
    public String sentMessage(Message messageData) {
        System.out.println("\n--- Message Options ---");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");
        
        while (true) {
            try {
                System.out.print("Choose an option (1-3): ");
                int choice = Integer.parseInt(scanner.nextLine());
                
                if (choice == 1) {
                    messagesSent.add(messageData);
                    messageCounter++;
                    System.out.println("Message successfully sent.");
                    return "sent";
                } else if (choice == 2) {
                    System.out.println("Press 0 to delete the message");
                    System.out.print("Enter 0 to confirm deletion: ");
                    String confirm = scanner.nextLine();
                    if (confirm.equals("0")) {
                        System.out.println("Message discarded.");
                        return "discarded";
                    } else {
                        System.out.println("Action cancelled. Keeping message.");
                        return "cancelled";
                    }
                } else if (choice == 3) {
                    messagesStored.add(messageData);
                    storeMessagesToFile();
                    System.out.println("Message successfully stored.");
                    return "stored";
                } else {
                    System.out.println("Please enter 1, 2, or 3.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
    
    public String printMessages() {
        if (messagesSent.isEmpty()) {
            return "No messages have been sent yet.";
        }
        
        StringBuilder result = new StringBuilder();
        result.append("\n============================================================\n");
        result.append("SENT MESSAGES\n");
        result.append("============================================================\n");
        
        for (int i = 0; i < messagesSent.size(); i++) {
            Message msg = messagesSent.get(i);
            result.append("\nMessage ").append(i + 1).append(":\n");
            result.append("  Message ID: ").append(msg.getMessageId()).append("\n");
            result.append("  Message Hash: ").append(msg.getMessageHash()).append("\n");
            result.append("  Recipient: ").append(msg.getRecipient()).append("\n");
            result.append("  Message: ").append(msg.getMessageText()).append("\n");
            result.append("----------------------------------------\n");
        }
        
        return result.toString();
    }
    
    public int returnTotalMessages() {
        return messageCounter;
    }
    
    public void storeMessagesToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("quickchat_messages.txt"))) {
            writer.println("=== QUICKCHAT STORED MESSAGES ===");
            writer.println("Last updated: " + new Date());
            writer.println();
            
            writer.println("SENT MESSAGES:");
            writer.println("--------------");
            for (Message msg : messagesSent) {
                writer.println("Message ID: " + msg.getMessageId());
                writer.println("Message Hash: " + msg.getMessageHash());
                writer.println("Recipient: " + msg.getRecipient());
                writer.println("Message: " + msg.getMessageText());
                writer.println("Message Number: " + msg.getMessageNumber());
                writer.println("Timestamp: " + msg.getTimestamp());
                writer.println("---");
            }
            
            writer.println("\nSTORED MESSAGES:");
            writer.println("----------------");
            for (Message msg : messagesStored) {
                writer.println("Message ID: " + msg.getMessageId());
                writer.println("Message Hash: " + msg.getMessageHash());
                writer.println("Recipient: " + msg.getRecipient());
                writer.println("Message: " + msg.getMessageText());
                writer.println("Message Number: " + msg.getMessageNumber());
                writer.println("Timestamp: " + msg.getTimestamp());
                writer.println("---");
            }
            
            writer.println("\nTotal Messages Sent: " + messageCounter);
        } catch (IOException e) {
            System.out.println("Error storing messages: " + e.getMessage());
        }
    }
    
    public void loadMessagesFromFile() {
        File file = new File("quickchat_messages.txt");
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Total Messages Sent: ")) {
                    String[] parts = line.split(": ");
                    if (parts.length == 2) {
                        messageCounter = Integer.parseInt(parts[1]);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading messages: " + e.getMessage());
        }
    }
    
    private String generateMessageId() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }
    
    public String validateMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send. (Length: " + message.length() + " characters)";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }
    
    public boolean sendMessageProcess(int messageNumber) {
        System.out.println("\n--- Message " + messageNumber + " of " + totalMessagesAllowed + " ---");
        
        String messageId = generateMessageId();
        System.out.println("Message ID generated: " + messageId);
        
        if (!checkMessageID(messageId)) {
            System.out.println("Error: Message ID too long!");
            return false;
        }
        
        String recipient;
        while (true) {
            System.out.print("Enter recipient number (with international code, e.g., +27718693002): ");
            recipient = scanner.nextLine();
            String result = checkRecipientCell(recipient);
            System.out.println(result);
            if (result.equals("Cell phone number successfully captured.")) {
                break;
            }
        }
        
        String messageText;
        while (true) {
            System.out.print("Enter your message (max 250 characters): ");
            messageText = scanner.nextLine();
            String validation = validateMessageLength(messageText);
            System.out.println(validation);
            if (validation.contains("ready to send")) {
                break;
            }
        }
        
        String messageHash = createMessageHash(messageId, messageNumber, messageText);
        System.out.println("Message Hash generated: " + messageHash);
        
        Message messageData = new Message(messageId, messageHash, recipient, messageText, messageNumber);
        
        System.out.println("\n--- Message Details ---");
        System.out.println("Message ID: " + messageId);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + messageText);
        
        String action = sentMessage(messageData);
        
        if (action.equals("sent")) {
            System.out.println("\n--- Message Successfully Sent ---");
            System.out.println("Message ID: " + messageId);
            System.out.println("Message Hash: " + messageHash);
            System.out.println("Recipient: " + recipient);
            System.out.println("Message: " + messageText);
            return true;
        }
        return false;
    }
    
    public void sendMessagesFlow() {
        if (!getTotalMessages()) return;
        
        int messagesSentCount = 0;
        
        for (int i = 1; i <= totalMessagesAllowed; i++) {
            if (sendMessageProcess(i)) {
                messagesSentCount++;
            }
            System.out.println("\n----------------------------------------");
        }
        
        System.out.println("\nTotal number of messages sent: " + messagesSentCount);
        
        if (messagesSentCount > 0) {
            System.out.println(printMessages());
        }
    }
    
    public boolean displayMenu() {
        System.out.println("\n==================================================");
        System.out.println("QUICKCHAT MENU");
        System.out.println("==================================================");
        System.out.println("1. Send Messages");
        System.out.println("2. Show recently sent messages");
        System.out.println("3. Quit");
        System.out.println("==================================================");
        
        while (true) {
            try {
                System.out.print("\nEnter your choice (1-3): ");
                int choice = Integer.parseInt(scanner.nextLine());
                
                if (choice == 1) {
                    sendMessagesFlow();
                } else if (choice == 2) {
                    System.out.println(printMessages());
                } else if (choice == 3) {
                    System.out.println("\nTotal messages sent: " + returnTotalMessages());
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    return false;
                } else {
                    System.out.println("Please enter 1, 2, or 3.");
                    continue;
                }
                return true;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
    
    public void runQuickChat() {
        loadMessagesFromFile();
        
        displayWelcome();
        
        boolean running = true;
        while (running) {
            running = displayMenu();
        }
        
        storeMessagesToFile();
    }
}